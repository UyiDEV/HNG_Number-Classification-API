from app import app  # Import your Flask app

def lambda_handler(event, context):
    """Handles Lambda events and passes them to the Flask app."""
    return app(event, context)